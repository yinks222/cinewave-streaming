# CineWave
A polished Next.js streaming UI prototype.

## Run
npm install
npm run dev

## Deploy
Import this project into Vercel and deploy. The interface uses remote Unsplash imagery and demo metadata; replace those with licensed catalog artwork and authorized video streams for production use.
