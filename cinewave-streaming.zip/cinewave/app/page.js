'use client';
import { useMemo, useState } from "react";
import { Play, Plus, Search, ChevronRight, X, Star, Clock, Info } from "lucide-react";

const movies = [
  {id:1,title:"Midnight Signal",year:2025,genre:"Sci-Fi",rating:"8.7",time:"2h 08m",img:"https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=900&q=80",hero:true,desc:"A radio astronomer intercepts a signal that seems to know the future."},
  {id:2,title:"Neon Horizon",year:2024,genre:"Action",rating:"8.1",time:"1h 54m",img:"https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=600&q=80"},
  {id:3,title:"Afterglow",year:2025,genre:"Drama",rating:"8.4",time:"2h 02m",img:"https://images.unsplash.com/photo-1500534623283-312aade485b7?auto=format&fit=crop&w=600&q=80"},
  {id:4,title:"The Last Atlas",year:2023,genre:"Adventure",rating:"8.8",time:"2h 21m",img:"https://images.unsplash.com/photo-1446776877081-d282a0f896e2?auto=format&fit=crop&w=600&q=80"},
  {id:5,title:"Velvet City",year:2024,genre:"Crime",rating:"7.9",time:"1h 47m",img:"https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=600&q=80"},
  {id:6,title:"Static Hearts",year:2025,genre:"Romance",rating:"8.2",time:"1h 42m",img:"https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?auto=format&fit=crop&w=600&q=80"},
  {id:7,title:"Wild Meridian",year:2022,genre:"Adventure",rating:"8.0",time:"2h 11m",img:"https://images.unsplash.com/photo-1500534623283-312aade485b7?auto=format&fit=crop&w=600&q=80"},
  {id:8,title:"Deep Blue",year:2024,genre:"Documentary",rating:"9.0",time:"1h 31m",img:"https://images.unsplash.com/photo-1469474968028-56623f02e42e?auto=format&fit=crop&w=600&q=80"},
  {id:9,title:"Nocturne",year:2023,genre:"Thriller",rating:"8.3",time:"1h 58m",img:"https://images.unsplash.com/photo-1500534623283-312aade485b7?auto=format&fit=crop&w=600&q=80"},
  {id:10,title:"Parallel",year:2025,genre:"Sci-Fi",rating:"8.6",time:"2h 06m",img:"https://images.unsplash.com/photo-1446776877081-d282a0f896e2?auto=format&fit=crop&w=600&q=80"}
];

export default function Home(){
 const [query,setQuery]=useState(""); const [genre,setGenre]=useState("All"); const [selected,setSelected]=useState(null);
 const genres=["All","Action","Drama","Sci-Fi","Adventure","Crime","Romance","Thriller"];
 const filtered=useMemo(()=>movies.filter(m=>(genre==="All"||m.genre===genre)&&m.title.toLowerCase().includes(query.toLowerCase())),[genre,query]);
 const featured=movies[0];
 return <main>
  <header className="nav">
    <div className="logo"><span className="logoMark">C</span>CINE<span>WAVE</span></div>
    <nav><a className="active">Home</a><a>Movies</a><a>Series</a><a>My List</a></nav>
    <div className="actions"><div className="search"><Search size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search movies..." /></div><button className="avatar">YW</button></div>
  </header>
  <section className="hero" style={{backgroundImage:`linear-gradient(90deg,rgba(5,7,12,.98) 0%,rgba(5,7,12,.8) 38%,rgba(5,7,12,.15) 72%,rgba(5,7,12,.9) 100%),url(${featured.img})`}}>
    <div className="heroCopy"><div className="eyebrow">CINEWAVE ORIGINAL</div><h1>{featured.title}</h1><div className="meta"><span>2025</span><span>16+</span><span>2h 08m</span><span className="rating"><Star size={14} fill="currentColor"/> {featured.rating}</span></div><p>{featured.desc}</p><div className="heroButtons"><button className="primary" onClick={()=>setSelected(featured)}><Play size={17} fill="currentColor"/> Watch now</button><button className="secondary"><Plus size={18}/> My List</button></div></div>
    <div className="scrollHint">SCROLL TO EXPLORE <ChevronRight size={15}/></div>
  </section>
  <section className="content">
    <div className="sectionTop"><div><p className="kicker">CURATED FOR YOU</p><h2>What’s playing</h2></div><button className="see">View all <ChevronRight size={16}/></button></div>
    <div className="chips">{genres.map(g=><button key={g} onClick={()=>setGenre(g)} className={genre===g?"chip on":"chip"}>{g}</button>)}</div>
    <div className="grid">{filtered.map(m=><article className="card" key={m.id} onClick={()=>setSelected(m)}><div className="poster"><img src={m.img}/><div className="cardShade"/><button className="playSmall" aria-label={`Play ${m.title}`}><Play size={15} fill="currentColor"/></button><span className="badge">{m.genre}</span></div><div className="cardInfo"><h3>{m.title}</h3><div><span>{m.year}</span><span>•</span><span>{m.time}</span><span className="miniRating"><Star size={11} fill="currentColor"/> {m.rating}</span></div></div></article>)}</div>
    <div className="railHeader"><div><p className="kicker">KEEP WATCHING</p><h2>Pick up where you left off</h2></div></div>
    <div className="wideRail">{movies.slice(2,6).map((m,i)=><div className="continue" key={m.id}><img src={m.img}/><div className="continueText"><span>EPISODE {i+1}</span><h3>{m.title}</h3><div className="progress"><i style={{width:`${35+i*13}%`}}/></div><small>{35+i*13}% watched</small></div></div>)}</div>
  </section>
  <footer><div className="logo"><span className="logoMark">C</span>CINE<span>WAVE</span></div><span>© 2026 CineWave. Demo streaming interface.</span><span>Terms · Privacy · Help</span></footer>
  {selected && <div className="modal" onClick={()=>setSelected(null)}><div className="modalBox" onClick={e=>e.stopPropagation()}><button className="close" onClick={()=>setSelected(null)}><X/></button><div className="player" style={{backgroundImage:`linear-gradient(0deg,#05070c,transparent),url(${selected.img})`}}><div className="playerCenter"><button className="playBig"><Play size={30} fill="currentColor"/></button><span>Demo player</span></div></div><div className="modalCopy"><div><p className="kicker">{selected.genre}</p><h2>{selected.title}</h2><div className="meta"><span>{selected.year}</span><span>{selected.time}</span><span className="rating"><Star size={14} fill="currentColor"/> {selected.rating}</span></div></div><button className="primary"><Play size={17} fill="currentColor"/> Start</button></div></div></div>}
 </main>
}